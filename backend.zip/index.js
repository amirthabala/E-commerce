var express = require('express');  
var app = express();  
var cors = require('cors');

app.use(cors());

app.get('/', function (req, res) {  
  res.send('Hello world!');  
});  


const start = () => {
    try{
        const server = app.listen(8080, '0.0.0.0', function(){
            console.log(`Server listening on`,server.address().port)
        })
    }catch (error){
  
    }
}
  
start()